<div id="wiloke-add-listing-fields">
	<div class="semantic-tabs ui top attached tabular menu">
		<div class="active item" data-tab="settings">Settings</div>
	</div>

	<?php
		require_once plugin_dir_path(__FILE__) . 'settings.php';
	?>
</div>