<?php

namespace WilokeListingTools\Models;


class AbstractUserPlan {

}