<?php

namespace WilokeListingTools\Controllers\TransformAddListingData;

interface TransformAddListingDataFactory
{
    public static function set($fieldType, $maximum = 100);
}
