<?php

namespace WilokeListingTools\Controllers\TransformAddListingData;

class TransformAddListingToFrontEnd implements TransformAddListingInterface
{
    public function input($input)
    {
        // TODO: Implement input() method.
    }
    
    public function output($st = null)
    {
        // TODO: Implement output() method.
    }
    
    public function format($format = null)
    {
        // TODO: Implement format() method.
    }
}
