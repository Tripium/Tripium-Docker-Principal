<?php

namespace WilokeListingTools\Framework\Helpers;


class RestaurantMenu {
	public static function deleteRestaurantMenu(){

	}
}