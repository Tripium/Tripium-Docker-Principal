#!/usr/bin/env bash
./wp-cli.phar theme activate $THEME_NAME
