<?php
return array(
	'plugin' => 'kc'
);