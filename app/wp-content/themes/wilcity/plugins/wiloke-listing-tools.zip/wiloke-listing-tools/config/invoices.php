<?php
return [
	'status' => array(
		'all'       => esc_html__('All', 'wiloke-listing-tools'),
		'refunded'  => esc_html__('Refunded', 'wiloke-listing-tools'),
		'succeeded' => esc_html__('Succeeded', 'wiloke-listing-tools'),
	)
];