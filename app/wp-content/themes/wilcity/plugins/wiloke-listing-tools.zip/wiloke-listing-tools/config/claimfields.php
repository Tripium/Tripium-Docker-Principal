<?php
return [
    array(
        'label'     => 'First Name',
        'key'       => 'first_name',
        'isRequired' => 'yes',
        'type'      => 'text'
    ),
    array(
        'label'     => 'Last Name',
        'key'       => 'last_name',
        'isRequired' => 'yes',
        'type'      => 'text'
    ),
    array(
        'label'     => 'Phone Number',
        'key'       => 'phone_number',
        'isRequired' => 'yes',
        'type'      => 'text'
    ),
    array(
        'label'     => 'Phone Number',
        'key'       => 'phone_number',
        'isRequired' => 'yes',
        'type'      => 'text'
    ),
    array(
        'label'     => 'Introducing your self',
        'key'       => 'introduce_your_self',
        'isRequired' => 'yes',
        'type'      => 'textarea'
    )
];
